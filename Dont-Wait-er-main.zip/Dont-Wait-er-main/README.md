# Dont-Wait-er
Dont Wait-er is an application that circumvents the need for immediate waiting staff. 
